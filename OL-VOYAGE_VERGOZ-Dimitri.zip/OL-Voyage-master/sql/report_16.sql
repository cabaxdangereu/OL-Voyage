SELECT employee_id "Numero d'employee", upper(last_name) || ' ' || first_name "Nom et Prenom", salary+100 "Salaire +"
FROM T_employee
ORDER BY "Numero d'employee"
/
